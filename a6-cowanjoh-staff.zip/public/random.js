"use strict";

function displayPersonData(person) {
  const tableBody = document.getElementById("data-table");
  const newRow = document.createElement("tr");

  // Portrait
  const portraitCell = document.createElement("td");
  const portraitImg = document.createElement("img");
  portraitImg.src = person.picture.thumbnail;
  portraitCell.appendChild(portraitImg);
  newRow.appendChild(portraitCell);

  // Name/Email
  const nameEmailCell = document.createElement("td");
  const emailLink = document.createElement("a");
  emailLink.href = `mailto:${person.email}`;
  emailLink.textContent = `${person.name.first} ${person.name.last}`;
  nameEmailCell.appendChild(emailLink);
  newRow.appendChild(nameEmailCell);

  // Telephone
  const telephoneCell = document.createElement("td");
  telephoneCell.textContent = person.phone;
  newRow.appendChild(telephoneCell);

  // City
  const cityCell = document.createElement("td");
  cityCell.textContent = person.location.city;
  newRow.appendChild(cityCell);

  tableBody.appendChild(newRow);
}

async function handleButtonClick(event) {
  event.preventDefault();
  const buttonId = event.target.getAttribute("id");

  // Check if the button is 'from-browser' or 'from-server'
  if (buttonId === "from-browser") {
    const response = await fetch("https://randomuser.me/api/");
    try {
      if (response.status === 200) {
        const data = await response.json();
        const person = data.results[0];
        displayPersonData(person);
      } else {
        console.error("Error: Failed to fetch data from the API.");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  } else if (buttonId === "from-server") {
    const response = await fetch("/random-person");
    try {
      if (response.status === 200) {
        const data = await response.json();
        const person = data.results[0];
        displayPersonData(person);
      } else {
        console.error("Error: Failed to fetch data from the server.");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  }
}

document.addEventListener("DOMContentLoaded", () => {
    const fromBrowserButton = document.getElementById("from-browser");
    fromBrowserButton.addEventListener("click", handleButtonClick);
  
    const fromServerButton = document.getElementById("from-server");
    fromServerButton.addEventListener("click", handleButtonClick);
  });